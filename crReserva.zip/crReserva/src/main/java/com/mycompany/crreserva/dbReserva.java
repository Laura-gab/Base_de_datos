
package com.mycompany.crreserva;

import java.sql.*;
import java.time.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class dbReserva {
    private int ReservaID; 
    private int PersonaID; 
    private int OrdenID; 
    private int ProveedorServicioID; 
    private boolean EstadoReserva; 
    private int CantidadPersonas; 
    private LocalTime HoraReserva; 
    private LocalDate FechaReserva; 
    private String NombreCliente;
    private int Celular;
    private String direccion;

    public int getReservaID() {
        return ReservaID;
    }

    public void setReservaID(int ReservaID) {
        this.ReservaID = ReservaID;
    }

    public int getPersonaID() {
        return PersonaID;
    }

    public void setPersonaID(int PersonaID) {
        this.PersonaID = PersonaID;
    }

    public int getOrdenID() {
        return OrdenID;
    }

    public void setOrdenID(int OrdenID) {
        this.OrdenID = OrdenID;
    }

    public int getProveedorServicioID() {
        return ProveedorServicioID;
    }

    public void setProveedorServicioID(int ProveedorServicioID) {
        this.ProveedorServicioID = ProveedorServicioID;
    }

    public boolean getEstadoReserva() {
        return EstadoReserva;
    }

    public void setEstadoReserva(boolean EstadoReserva) {
        this.EstadoReserva = EstadoReserva;
    }

    public int getCantidadPersonas() {
        return CantidadPersonas;
    }

    public void setCantidadPersonas(int CantidadPersonas) {
        this.CantidadPersonas = CantidadPersonas;
    }

    public LocalTime getHoraReserva() {
        return HoraReserva;
    }

    public void setHoraReserva(LocalTime HoraReserva) {
        this.HoraReserva = HoraReserva;
    }

    public LocalDate getFechaReserva() {
        return FechaReserva;
    }

    public void setFechaReserva(LocalDate FechaReserva) {
        this.FechaReserva = FechaReserva;
    }

    public String getNombreCliente() {
        return NombreCliente;
    }

    public void setNombreCliente(String NombreCliente) {
        this.NombreCliente = NombreCliente;
    }

    public int getCelular() {
        return Celular;
    }

    public void setCelular(int Celular) {
        this.Celular = Celular;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void crearReserva(JFormattedTextField paramHora, JFormattedTextField paramFecha, JTextField paramNombre, JFormattedTextField paramCantidad, JSpinner paramEstado, JTextField paramDireccion, JFormattedTextField paramCelular){
        setEstadoReserva((boolean)paramEstado.getValue());
        setCantidadPersonas((int) paramCantidad.getValue());
        setHoraReserva((LocalTime) paramHora.getValue());
        setFechaReserva((LocalDate) paramFecha.getValue());
        setNombreCliente(paramCantidad.getText());
        setCelular((int) paramCelular.getValue());
        setDireccion(paramDireccion.getText());
        
        EjemploConexionBases objetoConexion = new EjemploConexionBases();
        
        String consulta = "INSERT INTO Reserva (EstadoReserva, CantidadPersonas, HoraReserva, " +
                    "FechaReserva, NombreCliente, Celular, direccion) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try{
            CallableStatement cs =  objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setBoolean(1, getEstadoReserva());
            cs.setInt(2, getCantidadPersonas());
            cs.setTime(3, java.sql.Time.valueOf(getHoraReserva()));
            cs.setDate(4, java.sql.Date.valueOf(getFechaReserva()));
            cs.setString(5, getNombreCliente());
            cs.setInt(6, getCelular());
            cs.setString(7, getDireccion());
         
            cs.execute();
        
            cs.close();
            JOptionPane.showMessageDialog(null, "Reserva creada exitosamente");
        
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al crear la reserva: " + e.toString());
        }
    }
    
    public void mostrarTabla(JTable paramTabla){
        EjemploConexionBases objetoConexion = new EjemploConexionBases();
        
        DefaultTableModel modelo = new DefaultTableModel(); 
        
        String sql="";
        
        modelo.addColumn(ReservaID);
        modelo.addColumn(PersonaID);
        modelo.addColumn(OrdenID);
        modelo.addColumn(ProveedorServicioID);
        modelo.addColumn(EstadoReserva);
        modelo.addColumn(CantidadPersonas);
        modelo.addColumn(HoraReserva);
        modelo.addColumn(FechaReserva);
        modelo.addColumn(NombreCliente);
        modelo.addColumn(Celular);
        modelo.addColumn(direccion);
        
        paramTabla.setModel(modelo);
        
        sql="SELECT * FROM Reserva";
        
        String[] datos = new String[11];
        Statement st;
        
        try {
            st = objetoConexion.estableceConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                datos[5] = rs.getString(6);
                datos[6] = rs.getString(7);
                datos[7] = rs.getString(8);
                datos[8] = rs.getString(9);
                datos[9] = rs.getString(10);
                datos[10] = rs.getString(11);
                
                modelo.addRow(datos);
            }
            paramTabla.setModel(modelo);
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se pudo mostrar la tabla: " + e.toString());
        }
    }
    
    public void actualizar (JTable paramTabla, JFormattedTextField paramHora, JFormattedTextField paramFecha, JTextField paramNombre, JFormattedTextField paramCantidad, JSpinner paramEstado, JTextField paramDireccion, JFormattedTextField paramCelular){
        try{
            int fila = paramTabla.getSelectedRow();

            if (fila >= 0) {
            paramEstado.setValue(Boolean.valueOf(paramTabla.getValueAt(fila, 0).toString()));
            paramCantidad.setValue(Integer.parseInt(paramTabla.getValueAt(fila, 1).toString()));
            paramHora.setValue(LocalTime.parse(paramTabla.getValueAt(fila, 2).toString()));
            paramFecha.setValue(LocalDate.parse(paramTabla.getValueAt(fila, 3).toString()));
            paramNombre.setText(paramTabla.getValueAt(fila, 4).toString());
            paramCelular.setValue(Integer.parseInt(paramTabla.getValueAt(fila, 5).toString()));
            paramDireccion.setText(paramTabla.getValueAt(fila, 6).toString());
            }else{
            JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }    
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al cargar los datos: " + e.toString());
            System.out.println("Error específico: " + e.getMessage());
        }
    }
    
    public void actualizar (JTextField paramReservaID, JTextField paramPersonaID, JTextField paramOrdenID, JTextField paramProveedorID, JFormattedTextField paramHora, JFormattedTextField paramFecha, JTextField paramNombre, JFormattedTextField paramCantidad, JSpinner paramEstado, JTextField paramDireccion, JFormattedTextField paramCelular){
        
        setReservaID(Integer.parseInt(paramReservaID.getText()));
        setPersonaID(Integer.parseInt(paramPersonaID.getText()));
        setOrdenID(Integer.parseInt(paramOrdenID.getText()));
        setProveedorServicioID(Integer.parseInt(paramProveedorID.getText()));
        setEstadoReserva((boolean)paramEstado.getValue());
        setCantidadPersonas((int) paramCantidad.getValue());
        setHoraReserva((LocalTime) paramHora.getValue());
        setFechaReserva((LocalDate) paramFecha.getValue());
        setNombreCliente(paramCantidad.getText());
        setCelular((int) paramCelular.getValue());
        setDireccion(paramDireccion.getText());
        
        EjemploConexionBases objetoConexion = new EjemploConexionBases();
        
        String consulta = "UPDATE Reserva SET PersonaID = ?, OrdenID = ?, ProveedorServicioID = ?, \n" +
                        "EstadoReserva = ?, CantidadPersonas = ?, HoraReserva = ?, \n" +
                        "FechaReserva = ?,NombreCliente = ?, Celular = ?, Direccion = ?, WHERE ReservaID = ?;";
    
        try{
            CallableStatement cs =  objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setInt(1,getReservaID());
            cs.setInt(2,getPersonaID());
            cs.setInt(3,getOrdenID());
            cs.setInt(4,getProveedorServicioID());
            cs.setBoolean(5, getEstadoReserva());
            cs.setInt(6, getCantidadPersonas());
            cs.setTime(7, java.sql.Time.valueOf(getHoraReserva()));
            cs.setDate(8, java.sql.Date.valueOf(getFechaReserva()));
            cs.setString(9, getNombreCliente());
            cs.setInt(10, getCelular());
            cs.setString(11, getDireccion());
            
            cs.execute(consulta);
            
            JOptionPane.showMessageDialog(null,  "Modificación exitosa.");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se modifico: " + e.toString());
        }
    }
    
    public void eliminar (JTextField paramReservaID){
        
        setReservaID(Integer.parseInt(paramReservaID.getText()));
        EjemploConexionBases objetoConexion = new EjemploConexionBases();

        String consulta = "DELETE FROM Reserva WHERE ReservaID=?";

        try {
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            cs.setInt(1, getReservaID());
            cs.execute();

            JOptionPane.showMessageDialog(null, "Se eliminó correctamente el Alumno");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
        }
    }
}
