
package com.mycompany.crreserva;

public class CrReserva {

    public static void main(String[] args) {
        
        FrameReserva objetoReserva = new FrameReserva();
        objetoReserva.setVisible(true);
    }
}
